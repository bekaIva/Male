package com.bsoft.male

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
