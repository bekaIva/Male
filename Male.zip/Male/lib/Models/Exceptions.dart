class MessageException implements Exception {
  final String message;
  MessageException([this.message]);
}
